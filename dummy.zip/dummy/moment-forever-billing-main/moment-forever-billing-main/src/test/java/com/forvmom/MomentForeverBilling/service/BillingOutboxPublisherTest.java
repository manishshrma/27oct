package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.events.ReceiptDeliveryRequestedEvent;
import com.forvmom.MomentForeverBilling.repository.BillingOutboxRepository;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class BillingOutboxPublisherTest {

    @Test
    void nonResendDeliveryIsMovedToDltWithoutPublishingToBooking() {
        BillingOutboxService outboxService = mock(BillingOutboxService.class);
        KafkaTemplate<String, Object> kafkaTemplate = kafkaTemplate();
        BillingOutboxPublisher publisher = publisher(outboxService, kafkaTemplate);
        BillingOutbox outbox = pendingOutbox();
        ReceiptDeliveryRequestedEvent event = deliveryEvent(false);
        when(outboxService.readDeliveryEvent(outbox)).thenReturn(event);
        when(kafkaTemplate.send("receipt-delivery.DLT", event.getBookingId(), event))
                .thenReturn(completedSend());

        publisher.tryPublish(outbox);

        verify(kafkaTemplate, never()).send("receipt-delivery", event.getBookingId(), event);
        verify(kafkaTemplate).send("receipt-delivery.DLT", event.getBookingId(), event);
        verify(outboxService).markDead(outbox);
        verify(outboxService, never()).markSent(outbox);
    }

    @Test
    void explicitResendStillPublishesToBooking() {
        BillingOutboxService outboxService = mock(BillingOutboxService.class);
        KafkaTemplate<String, Object> kafkaTemplate = kafkaTemplate();
        BillingOutboxPublisher publisher = publisher(outboxService, kafkaTemplate);
        BillingOutbox outbox = pendingOutbox();
        ReceiptDeliveryRequestedEvent event = deliveryEvent(true);
        when(outboxService.readDeliveryEvent(outbox)).thenReturn(event);
        when(kafkaTemplate.send("receipt-delivery", event.getBookingId(), event))
                .thenReturn(completedSend());

        publisher.tryPublish(outbox);

        verify(kafkaTemplate).send("receipt-delivery", event.getBookingId(), event);
        verify(kafkaTemplate, never()).send("receipt-delivery.DLT", event.getBookingId(), event);
        verify(outboxService).markSent(outbox);
        verify(outboxService, never()).markDead(outbox);
    }

    private BillingOutboxPublisher publisher(
            BillingOutboxService outboxService,
            KafkaTemplate<String, Object> kafkaTemplate) {
        BillingOutboxPublisher publisher = new BillingOutboxPublisher(
                mock(BillingOutboxRepository.class),
                outboxService,
                kafkaTemplate,
                new BillingProperties());
        ReflectionTestUtils.setField(publisher, "receiptDeliveryTopic", "receipt-delivery");
        ReflectionTestUtils.setField(publisher, "receiptDeliveryDltTopic", "receipt-delivery.DLT");
        return publisher;
    }

    private BillingOutbox pendingOutbox() {
        BillingOutbox outbox = new BillingOutbox();
        outbox.setId("outbox-1");
        outbox.setAggregateId("receipt-1");
        outbox.setStatus(OutboxStatus.PENDING);
        return outbox;
    }

    private ReceiptDeliveryRequestedEvent deliveryEvent(boolean resend) {
        ReceiptDeliveryRequestedEvent event = new ReceiptDeliveryRequestedEvent();
        event.setBookingId("booking-1");
        event.setDocumentId("receipt-1");
        event.setResend(resend);
        return event;
    }

    private CompletableFuture<SendResult<String, Object>> completedSend() {
        return CompletableFuture.completedFuture(null);
    }

    @SuppressWarnings("unchecked")
    private KafkaTemplate<String, Object> kafkaTemplate() {
        return mock(KafkaTemplate.class);
    }
}
