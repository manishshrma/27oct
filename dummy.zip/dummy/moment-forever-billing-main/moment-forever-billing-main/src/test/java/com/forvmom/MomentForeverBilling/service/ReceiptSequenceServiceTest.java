package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.ReceiptSequence;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptSequenceServiceTest {

    @Test
    void usesThePrefixFrozenInTheFinancialYearSequence() {
        MongoTemplate mongoTemplate = mock(MongoTemplate.class);
        BillingProperties properties = new BillingProperties();
        properties.setReceiptPrefix("CURRENT");
        ReceiptSequence storedSequence = new ReceiptSequence();
        storedSequence.setPrefix("FROZEN");
        storedSequence.setNextValue(7);
        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(ReceiptSequence.class)))
                .thenReturn(storedSequence);

        ReceiptNumber receiptNumber = new ReceiptSequenceService(mongoTemplate, properties)
                .nextReceiptNumber(Instant.parse("2026-10-18T00:00:00Z"));

        assertEquals("FY2026-27", receiptNumber.financialYear());
        assertEquals("FROZEN-FY2026-27-000007", receiptNumber.value());
        ArgumentCaptor<Update> update = ArgumentCaptor.forClass(Update.class);
        verify(mongoTemplate).findAndModify(
                any(Query.class),
                update.capture(),
                any(FindAndModifyOptions.class),
                eq(ReceiptSequence.class));
        assertEquals("CURRENT", update.getValue().getUpdateObject()
                .get("$setOnInsert", org.bson.Document.class)
                .getString("prefix"));
    }
}
