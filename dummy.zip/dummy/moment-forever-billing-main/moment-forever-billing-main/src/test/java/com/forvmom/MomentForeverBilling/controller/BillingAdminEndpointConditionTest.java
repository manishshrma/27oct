package com.forvmom.MomentForeverBilling.controller;

import com.forvmom.MomentForeverBilling.service.BillingAdminQueryService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class BillingAdminEndpointConditionTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withUserConfiguration(ControllerConfiguration.class)
            .withBean(BillingAdminQueryService.class, () -> mock(BillingAdminQueryService.class));

    @Test
    void doesNotRegisterAdminEndpointsByDefault() {
        contextRunner.run(context ->
                assertThat(context).doesNotHaveBean(BillingAdminController.class));
    }

    @Test
    void registersAdminEndpointsOnlyWhenEnabled() {
        contextRunner.withPropertyValues("billing.admin.endpoints-enabled=true")
                .run(context -> assertThat(context).hasSingleBean(BillingAdminController.class));
    }

    @Configuration(proxyBeanMethods = false)
    @Import(BillingAdminController.class)
    static class ControllerConfiguration {
    }
}
