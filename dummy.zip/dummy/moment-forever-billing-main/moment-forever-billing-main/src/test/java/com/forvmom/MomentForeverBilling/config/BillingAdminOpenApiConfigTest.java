package com.forvmom.MomentForeverBilling.config;

import com.forvmom.MomentForeverBilling.controller.BillingAdminController;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import org.junit.jupiter.api.Test;
import org.springdoc.core.customizers.OpenApiCustomizer;

import static org.assertj.core.api.Assertions.assertThat;

class BillingAdminOpenApiConfigTest {

    @Test
    void hidesAdminPathsFromOpenApiByDefault() {
        BillingProperties properties = new BillingProperties();
        OpenApiCustomizer customizer = new BillingAdminOpenApiConfig()
                .billingAdminOpenApiCustomizer(properties);
        OpenAPI openApi = openApi();

        customizer.customise(openApi);

        assertThat(openApi.getPaths()).doesNotContainKey(
                BillingAdminController.BASE_PATH + "/receipts");
        assertThat(openApi.getPaths()).containsKey("/api/receipts/availability");
    }

    @Test
    void keepsAdminPathsInOpenApiWhenVisibilityIsEnabled() {
        BillingProperties properties = new BillingProperties();
        properties.getAdmin().setSwaggerVisible(true);
        OpenApiCustomizer customizer = new BillingAdminOpenApiConfig()
                .billingAdminOpenApiCustomizer(properties);
        OpenAPI openApi = openApi();

        customizer.customise(openApi);

        assertThat(openApi.getPaths()).containsKey(
                BillingAdminController.BASE_PATH + "/receipts");
    }

    private OpenAPI openApi() {
        Paths paths = new Paths();
        paths.addPathItem(BillingAdminController.BASE_PATH + "/receipts", new PathItem());
        paths.addPathItem("/api/receipts/availability", new PathItem());
        return new OpenAPI().paths(paths);
    }
}
