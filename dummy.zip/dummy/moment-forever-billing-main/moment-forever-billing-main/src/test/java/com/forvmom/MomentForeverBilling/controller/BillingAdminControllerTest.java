package com.forvmom.MomentForeverBilling.controller;

import com.forvmom.MomentForeverBilling.dto.AdminReceiptResponse;
import com.forvmom.MomentForeverBilling.exception.BillingApiExceptionHandler;
import com.forvmom.MomentForeverBilling.service.BillingAdminQueryService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(
        controllers = BillingAdminController.class,
        properties = "billing.admin.endpoints-enabled=true")
@Import(BillingApiExceptionHandler.class)
class BillingAdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BillingAdminQueryService billingAdminQueryService;

    @Test
    void rejectsRequestsWithoutTrustedAdministrativeRole() throws Exception {
        mockMvc.perform(get("/admin/receipt-tracking/receipts"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("An administrative role is required"));

        verifyNoInteractions(billingAdminQueryService);
    }

    @Test
    void rejectsRequestsFromNonAdministrativeRole() throws Exception {
        mockMvc.perform(get("/admin/receipt-tracking/receipts")
                        .header("X-User-Roles", "CUSTOMER"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("An administrative role is required"));

        verifyNoInteractions(billingAdminQueryService);
    }

    @Test
    void allowsAdminToListOnlySafeReceiptFields() throws Exception {
        AdminReceiptResponse receipt = new AdminReceiptResponse(
                "receipt_100",
                "MFB-100",
                "MF-R-2026-000001",
                "2026-27",
                "PAYMENT_RECEIPT_NON_GST",
                "ISSUED",
                Instant.parse("2026-10-19T08:00:00Z"));
        when(billingAdminQueryService.receipts(eq("MFB-100"), isNull(), isNull(), eq(0), eq(25)))
                .thenReturn(new PageImpl<>(List.of(receipt)));

        mockMvc.perform(get("/admin/receipt-tracking/receipts")
                        .header("X-User-Roles", "USER, SUPER_ADMIN")
                        .param("bookingId", "MFB-100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].bookingId").value("MFB-100"))
                .andExpect(jsonPath("$.content[0].receiptNumber").value("MF-R-2026-000001"))
                .andExpect(jsonPath("$.content[0].trustedAccountEmail").doesNotExist())
                .andExpect(jsonPath("$.content[0].paymentTransactionId").doesNotExist())
                .andExpect(jsonPath("$.content[0].storage").doesNotExist());
    }
}
