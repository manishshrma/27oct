package com.forvmom.MomentForeverBilling.consumer;

import com.forvmom.MomentForeverBilling.events.ExperienceCompletedEvent;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateResult;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class ExperienceCompletedConsumer {

    private static final Logger log = LoggerFactory.getLogger(ExperienceCompletedConsumer.class);

    private final ReceiptCandidateService receiptCandidateService;

    public ExperienceCompletedConsumer(ReceiptCandidateService receiptCandidateService) {
        this.receiptCandidateService = receiptCandidateService;
    }

    @KafkaListener(
            topics = "${kafka.topics.experience-completed}",
            groupId = "billing-receipt-completion-group",
            containerFactory = "billingKafkaListenerContainerFactory")
    public void onExperienceCompleted(
            @Payload ExperienceCompletedEvent event,
            Acknowledgment acknowledgment) {
        ReceiptCandidateResult result = receiptCandidateService.complete(event);
        acknowledgment.acknowledge();
        log.info("Experience completion handled: bookingId={}, resolution={}",
                event.getBookingId(), result.resolutionCode());
    }
}
