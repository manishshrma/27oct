package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.ExperienceCompletionEvidence;
import com.forvmom.MomentForeverBilling.domain.FinanceReviewCase;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.events.ExperienceCompletedEvent;
import com.forvmom.MomentForeverBilling.events.ReceiptEligibilityCapturedEvent;
import com.forvmom.MomentForeverBilling.events.ReceiptGenerationRequestedEvent;
import com.forvmom.MomentForeverBilling.repository.ExperienceCompletionEvidenceRepository;
import com.forvmom.MomentForeverBilling.repository.FinanceReviewCaseRepository;
import com.forvmom.MomentForeverBilling.repository.ReceiptCandidateRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;

@Service
public class ReceiptCandidateService {

    private final ReceiptCandidateRepository candidateRepository;
    private final ExperienceCompletionEvidenceRepository completionRepository;
    private final FinanceReviewCaseRepository financeReviewCaseRepository;
    private final ReceiptIssuanceService receiptIssuanceService;
    private final BillingProperties properties;

    public ReceiptCandidateService(
            ReceiptCandidateRepository candidateRepository,
            ExperienceCompletionEvidenceRepository completionRepository,
            FinanceReviewCaseRepository financeReviewCaseRepository,
            ReceiptIssuanceService receiptIssuanceService,
            BillingProperties properties) {
        this.candidateRepository = candidateRepository;
        this.completionRepository = completionRepository;
        this.financeReviewCaseRepository = financeReviewCaseRepository;
        this.receiptIssuanceService = receiptIssuanceService;
        this.properties = properties;
    }

    @Transactional
    public ReceiptCandidateResult capture(ReceiptEligibilityCapturedEvent event) {
        requireEventId(event.getEventId(), "Receipt eligibility event id is required");
        ReceiptCandidate existingByEvent = candidateRepository.findBySourceEventId(event.getEventId()).orElse(null);
        if (existingByEvent != null) {
            return reconcileCandidate(existingByEvent);
        }
        ReceiptCandidate existingByBooking = findCandidateByBookingId(event.getBookingId());
        if (existingByBooking != null) {
            return reconcileCandidate(existingByBooking);
        }

        ReceiptCandidate candidate = newCandidate(event);
        String reviewReason = reviewReason(event);
        if (reviewReason != null) {
            candidate.setStatus(ReceiptCandidateStatus.REVIEW_REQUIRED);
            candidate.setResolutionCode(reviewReason);
        } else if (event.getPaidAt().isBefore(properties.getReceiptFeatureLaunchAt())) {
            candidate.setStatus(ReceiptCandidateStatus.NOT_ELIGIBLE);
            candidate.setResolutionCode("PRE_FEATURE_LAUNCH");
        } else {
            candidate.setStatus(ReceiptCandidateStatus.PENDING_COMPLETION);
            candidate.setResolutionCode("PENDING_COMPLETION");
        }

        try {
            candidateRepository.insert(candidate);
        } catch (DuplicateKeyException duplicate) {
            return reconcileCandidate(findExistingCandidate(event, duplicate));
        }

        if (reviewReason != null) {
            createFinanceReview(candidate, reviewReason);
            return ReceiptCandidateResult.resolved(reviewReason);
        }
        if (candidate.getStatus() == ReceiptCandidateStatus.NOT_ELIGIBLE) {
            return ReceiptCandidateResult.resolved("PRE_FEATURE_LAUNCH");
        }

        return reconcileCandidate(candidate);
    }

    @Transactional
    public ReceiptCandidateResult complete(ExperienceCompletedEvent event) {
        requireEventId(event.getEventId(), "Experience completion event id is required");
        if (!StringUtils.hasText(event.getBookingId())) {
            throw new IllegalArgumentException("Experience completion booking id is required");
        }
        if (completionRepository.findByEventId(event.getEventId()).isPresent()) {
            return reconcileBooking(event.getBookingId(), "DUPLICATE_EVENT", true);
        }
        if (completionRepository.findByBookingId(event.getBookingId()).isPresent()) {
            return reconcileBooking(event.getBookingId(), "DUPLICATE_BOOKING_COMPLETION", true);
        }

        ExperienceCompletionEvidence completion = new ExperienceCompletionEvidence();
        completion.setEventId(event.getEventId());
        completion.setProducer(event.getProducer());
        completion.setBookingId(event.getBookingId());
        completion.setCompletedAt(event.getCompletedAt());
        completion.setReceivedAt(Instant.now());
        try {
            completionRepository.insert(completion);
        } catch (DuplicateKeyException duplicate) {
            return reconcileBooking(event.getBookingId(), "DUPLICATE_EVENT", true);
        }

        return reconcileBooking(event.getBookingId(), "WAITING_FOR_CANDIDATE", true);
    }

    @Scheduled(fixedDelayString = "${billing.receipt-candidate-reconciliation-poll-ms:30000}")
    @Transactional
    public void reconcileReadyCandidates() {
        for (ReceiptCandidate candidate : candidateRepository.findByStatus(ReceiptCandidateStatus.PENDING_COMPLETION)) {
            reconcileCandidate(candidate);
        }
    }

    @Transactional
    public ReceiptCandidateResult captureLegacy(ReceiptGenerationRequestedEvent event) {
        ReceiptEligibilityCapturedEvent capture = new ReceiptEligibilityCapturedEvent();
        capture.setEventId(event.getEventId());
        capture.setProducer(event.getProducer());
        capture.setCorrelationId(event.getCorrelationId());
        capture.setCausationId(event.getCausationId());
        capture.setSchemaVersion(event.getSchemaVersion());
        capture.setOccurredAt(event.getOccurredAt());
        capture.setEventType(event.getEventType());
        capture.setBookingId(event.getBookingId());
        capture.setUserId(event.getUserId());
        capture.setUserEmail(event.getUserEmail());
        capture.setUserFullName(event.getUserFullName());
        capture.setExperienceName(event.getExperienceName());
        capture.setBookingDate(event.getBookingDate());
        capture.setExpectedAmount(event.getExpectedAmount());
        capture.setExpectedCurrency(event.getExpectedCurrency());
        capture.setPaymentTransactionId(event.getPaymentTransactionId());
        capture.setAmountPaid(event.getAmountPaid());
        capture.setCurrencyPaid(event.getCurrencyPaid());
        capture.setPaidAt(event.getPaidAt());
        return capture(capture);
    }

    private ReceiptCandidate newCandidate(ReceiptEligibilityCapturedEvent event) {
        ReceiptCandidate candidate = new ReceiptCandidate();
        candidate.setSourceEventId(event.getEventId());
        candidate.setSourceProducer(event.getProducer());
        candidate.setBookingId(event.getBookingId());
        candidate.setOwnerUserId(event.getUserId());
        candidate.setTrustedAccountEmail(event.getUserEmail());
        candidate.setUserFullName(event.getUserFullName());
        candidate.setExperienceName(event.getExperienceName());
        candidate.setBookingDate(event.getBookingDate());
        candidate.setExpectedAmount(event.getExpectedAmount());
        candidate.setExpectedCurrency(event.getExpectedCurrency());
        candidate.setPaymentTransactionId(event.getPaymentTransactionId());
        candidate.setAmountPaid(event.getAmountPaid());
        candidate.setCurrencyPaid(event.getCurrencyPaid());
        candidate.setPaidAt(event.getPaidAt());
        candidate.setCapturedAt(Instant.now());
        return candidate;
    }

    private ReceiptCandidateResult reconcileBooking(
            String bookingId,
            String noCandidateResolution,
            boolean completionAlreadySaved) {
        ReceiptCandidate candidate = findCandidateByBookingId(bookingId);
        if (candidate == null) {
            return ReceiptCandidateResult.resolved(noCandidateResolution);
        }
        return reconcileCandidate(candidate, completionAlreadySaved);
    }

    private ReceiptCandidateResult reconcileCandidate(ReceiptCandidate candidate) {
        return reconcileCandidate(candidate, false);
    }

    private ReceiptCandidateResult reconcileCandidate(
            ReceiptCandidate candidate,
            boolean completionAlreadySaved) {
        if (candidate.getStatus() != ReceiptCandidateStatus.PENDING_COMPLETION) {
            return ReceiptCandidateResult.resolved(candidateResolution(candidate));
        }
        if (!completionAlreadySaved
                && (!StringUtils.hasText(candidate.getBookingId())
                || completionRepository.findByBookingId(candidate.getBookingId()).isEmpty())) {
            return ReceiptCandidateResult.resolved("PENDING_COMPLETION");
        }
        return ReceiptCandidateResult.resolved(receiptIssuanceService.issueIfReady(candidate).resolutionCode());
    }

    private ReceiptCandidate findExistingCandidate(
            ReceiptEligibilityCapturedEvent event,
            DuplicateKeyException duplicate) {
        ReceiptCandidate existingByEvent = candidateRepository.findBySourceEventId(event.getEventId()).orElse(null);
        if (existingByEvent != null) {
            return existingByEvent;
        }
        ReceiptCandidate existingByBooking = findCandidateByBookingId(event.getBookingId());
        if (existingByBooking != null) {
            return existingByBooking;
        }
        throw duplicate;
    }

    private ReceiptCandidate findCandidateByBookingId(String bookingId) {
        if (!StringUtils.hasText(bookingId)) {
            return null;
        }
        return candidateRepository.findByBookingId(bookingId).orElse(null);
    }

    private String candidateResolution(ReceiptCandidate candidate) {
        if (StringUtils.hasText(candidate.getResolutionCode())) {
            return candidate.getResolutionCode();
        }
        return candidate.getStatus() == null ? "UNKNOWN" : candidate.getStatus().name();
    }

    private String reviewReason(ReceiptEligibilityCapturedEvent event) {
        if (!StringUtils.hasText(event.getBookingId())
                || event.getUserId() == null
                || !StringUtils.hasText(event.getPaymentTransactionId())
                || event.getExpectedAmount() == null
                || event.getAmountPaid() == null
                || !StringUtils.hasText(event.getExpectedCurrency())
                || !StringUtils.hasText(event.getCurrencyPaid())
                || event.getPaidAt() == null) {
            return "PAYMENT_EVIDENCE_INCOMPLETE";
        }
        if (!properties.getCurrency().equalsIgnoreCase(event.getExpectedCurrency())
                || !properties.getCurrency().equalsIgnoreCase(event.getCurrencyPaid())) {
            return "CURRENCY_MISMATCH";
        }
        if (event.getExpectedAmount().compareTo(event.getAmountPaid()) != 0) {
            return "AMOUNT_MISMATCH";
        }
        return null;
    }

    private void createFinanceReview(ReceiptCandidate candidate, String reasonCode) {
        FinanceReviewCase review = new FinanceReviewCase();
        review.setBookingId(candidate.getBookingId());
        review.setSourceEventId(candidate.getSourceEventId());
        review.setReasonCode(reasonCode);
        review.setExpectedAmount(candidate.getExpectedAmount());
        review.setPaidAmount(candidate.getAmountPaid());
        review.setExpectedCurrency(candidate.getExpectedCurrency());
        review.setPaidCurrency(candidate.getCurrencyPaid());
        review.setPaymentTransactionId(candidate.getPaymentTransactionId());
        review.setStatus("OPEN");
        review.setCreatedAt(Instant.now());
        financeReviewCaseRepository.insert(review);
    }

    private void requireEventId(String eventId, String message) {
        if (!StringUtils.hasText(eventId)) {
            throw new IllegalArgumentException(message);
        }
    }
}
