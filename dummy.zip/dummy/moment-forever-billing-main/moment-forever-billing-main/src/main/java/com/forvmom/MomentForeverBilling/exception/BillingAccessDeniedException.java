package com.forvmom.MomentForeverBilling.exception;

public class BillingAccessDeniedException extends RuntimeException {
    public BillingAccessDeniedException(String message) {
        super(message);
    }
}
