package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.domain.StorageMetadata;
import com.forvmom.MomentForeverBilling.repository.FiscalDocumentRepository;
import com.forvmom.MomentForeverBilling.repository.ReceiptCandidateRepository;
import com.forvmom.MomentForeverBilling.storage.StorageRegistry;
import com.forvmom.MomentForeverBilling.storage.StoredDocument;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class ReceiptIssuanceService {

    private final FiscalDocumentRepository fiscalDocumentRepository;
    private final ReceiptCandidateRepository candidateRepository;
    private final ReceiptSequenceService receiptSequenceService;
    private final ReceiptPdfRenderer pdfRenderer;
    private final StorageRegistry storageRegistry;
    private final BillingProperties properties;

    public ReceiptIssuanceService(
            FiscalDocumentRepository fiscalDocumentRepository,
            ReceiptCandidateRepository candidateRepository,
            ReceiptSequenceService receiptSequenceService,
            ReceiptPdfRenderer pdfRenderer,
            StorageRegistry storageRegistry,
            BillingProperties properties) {
        this.fiscalDocumentRepository = fiscalDocumentRepository;
        this.candidateRepository = candidateRepository;
        this.receiptSequenceService = receiptSequenceService;
        this.pdfRenderer = pdfRenderer;
        this.storageRegistry = storageRegistry;
        this.properties = properties;
    }

    @Transactional
    public ReceiptIssuanceResult issueIfReady(ReceiptCandidate candidate) {
        if (candidate.getStatus() != ReceiptCandidateStatus.PENDING_COMPLETION) {
            return ReceiptIssuanceResult.skipped(candidate.getStatus().name());
        }

        FiscalDocument existing = fiscalDocumentRepository.findByBookingId(candidate.getBookingId()).orElse(null);
        if (existing != null) {
            markIssued(candidate, existing.getIssuedAt());
            return ReceiptIssuanceResult.skipped("RECEIPT_ALREADY_ISSUED");
        }

        candidate.setStatus(ReceiptCandidateStatus.PREPARING);
        FiscalDocument document = newFiscalDocument(candidate);
        byte[] pdf = pdfRenderer.render(document);
        StoredDocument storedDocument = storageRegistry.store(pdf, "application/pdf");
        document.setStorage(new StorageMetadata(
                storedDocument.provider(),
                storedDocument.storageKey(),
                sha256(pdf),
                storedDocument.sizeBytes(),
                storedDocument.contentType()));

        try {
            fiscalDocumentRepository.insert(document);
        } catch (DuplicateKeyException duplicate) {
            storageRegistry.delete(document.getStorage());
            FiscalDocument issued = fiscalDocumentRepository.findByBookingId(candidate.getBookingId())
                    .orElseThrow(() -> duplicate);
            markIssued(candidate, issued.getIssuedAt());
            return ReceiptIssuanceResult.skipped("RECEIPT_ALREADY_ISSUED");
        }

        markIssued(candidate, document.getIssuedAt());
        return ReceiptIssuanceResult.issued();
    }

    private FiscalDocument newFiscalDocument(ReceiptCandidate candidate) {
        Instant issuedAt = Instant.now();
        ReceiptNumber receiptNumber = receiptSequenceService.nextReceiptNumber(issuedAt);
        FiscalDocument document = new FiscalDocument();
        document.setDocumentId("receipt_" + UUID.randomUUID());
        document.setBookingId(candidate.getBookingId());
        document.setOwnerUserId(candidate.getOwnerUserId());
        document.setTrustedAccountEmail(candidate.getTrustedAccountEmail());
        document.setDocumentType("PAYMENT_RECEIPT_NON_GST");
        document.setReceiptNumber(receiptNumber.value());
        document.setFinancialYear(receiptNumber.financialYear());
        document.setStatus(DocumentStatus.ISSUED);
        document.setIssuedAt(issuedAt);
        document.setIssuerName(properties.getIssuerName());
        document.setIssuerCountry(properties.getIssuerCountry());
        document.setCurrency(properties.getCurrency());
        document.setExpectedAmount(candidate.getExpectedAmount());
        document.setPaidAmount(candidate.getAmountPaid());
        document.setPaymentTransactionId(candidate.getPaymentTransactionId());
        document.setPaymentPaidAt(candidate.getPaidAt());
        document.setExperienceName(candidate.getExperienceName());
        document.setBookingDate(candidate.getBookingDate());
        return document;
    }

    private void markIssued(ReceiptCandidate candidate, Instant issuedAt) {
        candidate.setStatus(ReceiptCandidateStatus.ISSUED);
        candidate.setIssuedAt(issuedAt);
        candidate.setResolutionCode("ISSUED");
        candidateRepository.save(candidate);
    }

    private String sha256(byte[] content) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(content));
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }
}
