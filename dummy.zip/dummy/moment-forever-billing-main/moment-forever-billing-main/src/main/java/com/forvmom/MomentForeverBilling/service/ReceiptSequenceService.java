package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.ReceiptSequence;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Locale;

@Service
public class ReceiptSequenceService {

    private final MongoTemplate mongoTemplate;
    private final BillingProperties properties;

    public ReceiptSequenceService(MongoTemplate mongoTemplate, BillingProperties properties) {
        this.mongoTemplate = mongoTemplate;
        this.properties = properties;
    }

    public ReceiptNumber nextReceiptNumber(Instant issuedAt) {
        String financialYear = financialYearFor(issuedAt);
        ReceiptSequence sequence = mongoTemplate.findAndModify(
                Query.query(Criteria.where("_id").is(financialYear)),
                new Update()
                        .inc("nextValue", 1)
                        .setOnInsert("prefix", properties.getReceiptPrefix()),
                FindAndModifyOptions.options().upsert(true).returnNew(true),
                ReceiptSequence.class);
        if (sequence == null) {
            throw new IllegalStateException("Could not allocate a receipt number");
        }
        String number = String.format(
                Locale.ROOT,
                "%s-%s-%06d",
                sequence.getPrefix() == null ? properties.getReceiptPrefix() : sequence.getPrefix(),
                financialYear,
                sequence.getNextValue());
        return new ReceiptNumber(financialYear, number);
    }

    private String financialYearFor(Instant instant) {
        int startMonth = properties.getFinancialYearStartMonth();
        if (startMonth < 1 || startMonth > 12) {
            throw new IllegalStateException("billing.financial-year-start-month must be between 1 and 12");
        }
        ZonedDateTime date = instant.atZone(ZoneOffset.UTC);
        int startYear = date.getMonthValue() >= startMonth ? date.getYear() : date.getYear() - 1;
        return String.format(Locale.ROOT, "FY%d-%02d", startYear, (startYear + 1) % 100);
    }
}
