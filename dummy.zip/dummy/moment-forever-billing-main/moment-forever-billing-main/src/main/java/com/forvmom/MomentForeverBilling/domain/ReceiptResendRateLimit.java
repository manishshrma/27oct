package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document("receipt_resend_rate_limits")
public class ReceiptResendRateLimit {

    @Id
    private String id;

    private int count;
    private Instant windowExpiresAt;
}
