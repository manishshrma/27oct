package com.forvmom.MomentForeverBilling.service;

public record ReceiptNumber(String financialYear, String value) {
}
