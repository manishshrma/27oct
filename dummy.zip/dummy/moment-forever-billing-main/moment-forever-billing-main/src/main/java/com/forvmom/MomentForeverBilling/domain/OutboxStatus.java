package com.forvmom.MomentForeverBilling.domain;

public enum OutboxStatus {
    PENDING,
    SENT,
    FAILED,
    DEAD
}
