package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FinanceReviewCase;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.dto.AdminFinanceReviewResponse;
import com.forvmom.MomentForeverBilling.dto.AdminOutboxResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptCandidateResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@Service
public class BillingAdminQueryService {

    private static final int MAX_PAGE_SIZE = 100;

    private final MongoTemplate mongoTemplate;

    public BillingAdminQueryService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Page<AdminReceiptResponse> receipts(
            String bookingId,
            Instant from,
            Instant to,
            int page,
            int size) {
        List<Criteria> criteria = new ArrayList<>();
        criteria.add(Criteria.where("status").is(DocumentStatus.ISSUED));
        addBookingId(criteria, bookingId);
        addDateRange(criteria, "issuedAt", from, to);
        return findPage(
                criteria,
                FiscalDocument.class,
                page,
                size,
                Sort.by(Sort.Direction.DESC, "issuedAt").and(Sort.by(Sort.Direction.DESC, "documentId")),
                document -> new AdminReceiptResponse(
                        document.getDocumentId(),
                        document.getBookingId(),
                        document.getReceiptNumber(),
                        document.getFinancialYear(),
                        document.getDocumentType(),
                        document.getStatus().name(),
                        document.getIssuedAt()));
    }

    public Page<AdminReceiptCandidateResponse> candidates(
            String bookingId,
            ReceiptCandidateStatus status,
            Instant from,
            Instant to,
            int page,
            int size) {
        List<Criteria> criteria = new ArrayList<>();
        criteria.add(Criteria.where("status").ne(ReceiptCandidateStatus.ISSUED));
        if (status != null) {
            criteria.add(Criteria.where("status").is(status));
        }
        addBookingId(criteria, bookingId);
        addDateRange(criteria, "capturedAt", from, to);
        return findPage(
                criteria,
                ReceiptCandidate.class,
                page,
                size,
                Sort.by(Sort.Direction.DESC, "capturedAt").and(Sort.by(Sort.Direction.DESC, "bookingId")),
                candidate -> new AdminReceiptCandidateResponse(
                        candidate.getBookingId(),
                        candidate.getStatus().name(),
                        candidate.getResolutionCode(),
                        candidate.getCapturedAt(),
                        candidate.getIssuedAt()));
    }

    public Page<AdminFinanceReviewResponse> financeReviews(
            String bookingId,
            String status,
            Instant from,
            Instant to,
            int page,
            int size) {
        List<Criteria> criteria = new ArrayList<>();
        addBookingId(criteria, bookingId);
        if (StringUtils.hasText(status)) {
            criteria.add(Criteria.where("status").is(status.trim()));
        }
        addDateRange(criteria, "createdAt", from, to);
        return findPage(
                criteria,
                FinanceReviewCase.class,
                page,
                size,
                Sort.by(Sort.Direction.DESC, "createdAt").and(Sort.by(Sort.Direction.DESC, "bookingId")),
                review -> new AdminFinanceReviewResponse(
                        review.getBookingId(),
                        review.getReasonCode(),
                        review.getStatus(),
                        review.getCreatedAt()));
    }

    public Page<AdminOutboxResponse> outbox(
            OutboxStatus status,
            Instant from,
            Instant to,
            int page,
            int size) {
        List<Criteria> criteria = new ArrayList<>();
        if (status != null) {
            criteria.add(Criteria.where("status").is(status));
        }
        addDateRange(criteria, "updatedAt", from, to);
        return findPage(
                criteria,
                BillingOutbox.class,
                page,
                size,
                Sort.by(Sort.Direction.DESC, "updatedAt").and(Sort.by(Sort.Direction.DESC, "aggregateId")),
                outbox -> new AdminOutboxResponse(
                        outbox.getAggregateId(),
                        outbox.getEventType(),
                        outbox.getStatus().name(),
                        outbox.getRetryCount(),
                        outbox.getCreatedAt(),
                        outbox.getUpdatedAt()));
    }

    private <T, R> Page<R> findPage(
            List<Criteria> criteria,
            Class<T> entityType,
            int page,
            int size,
            Sort sort,
            Function<T, R> responseMapper) {
        Pageable pageable = pageRequest(page, size, sort);
        Query query = query(criteria);
        long total = mongoTemplate.count(query, entityType);
        List<R> content = mongoTemplate.find(query.with(pageable), entityType)
                .stream()
                .map(responseMapper)
                .toList();
        return new PageImpl<>(content, pageable, total);
    }

    private Query query(List<Criteria> criteria) {
        if (criteria.isEmpty()) {
            return new Query();
        }
        return new Query(new Criteria().andOperator(criteria.toArray(Criteria[]::new)));
    }

    private Pageable pageRequest(int page, int size, Sort sort) {
        if (page < 0) {
            throw new IllegalArgumentException("page must be zero or greater");
        }
        if (size < 1 || size > MAX_PAGE_SIZE) {
            throw new IllegalArgumentException("size must be between 1 and " + MAX_PAGE_SIZE);
        }
        return PageRequest.of(page, size, sort);
    }

    private void addBookingId(List<Criteria> criteria, String bookingId) {
        if (StringUtils.hasText(bookingId)) {
            criteria.add(Criteria.where("bookingId").is(bookingId.trim()));
        }
    }

    private void addDateRange(List<Criteria> criteria, String field, Instant from, Instant to) {
        if (from != null && to != null && from.isAfter(to)) {
            throw new IllegalArgumentException("from must not be after to");
        }
        if (from == null && to == null) {
            return;
        }
        Criteria dateRange = Criteria.where(field);
        if (from != null) {
            dateRange.gte(from);
        }
        if (to != null) {
            dateRange.lte(to);
        }
        criteria.add(dateRange);
    }
}
