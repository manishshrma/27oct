package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document("receipt_delivery_audit")
@CompoundIndex(name = "receipt_delivery_rate_limit", def = "{'documentId': 1, 'requestorUserId': 1, 'createdAt': 1}")
public class DeliveryAudit {

    @Id
    private String id;

    private String documentId;
    private Long requestorUserId;
    private String recipientHash;
    private String recipientSource;
    private String action;
    private Instant createdAt;
}
