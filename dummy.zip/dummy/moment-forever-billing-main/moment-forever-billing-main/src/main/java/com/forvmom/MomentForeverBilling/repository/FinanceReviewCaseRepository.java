package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.FinanceReviewCase;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FinanceReviewCaseRepository extends MongoRepository<FinanceReviewCase, String> {
}
