package com.forvmom.MomentForeverBilling.controller;

import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.dto.ReceiptAvailabilityResponse;
import com.forvmom.MomentForeverBilling.dto.ResendReceiptRequest;
import com.forvmom.MomentForeverBilling.dto.ResendReceiptResponse;
import com.forvmom.MomentForeverBilling.service.BillingOutboxPublisher;
import com.forvmom.MomentForeverBilling.service.ReceiptDeliveryService;
import com.forvmom.MomentForeverBilling.service.ReceiptFile;
import com.forvmom.MomentForeverBilling.service.ReceiptQueryService;
import jakarta.validation.Valid;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@RequestMapping("/api/receipts")
public class ReceiptController {

    private final ReceiptQueryService receiptQueryService;
    private final ReceiptDeliveryService receiptDeliveryService;
    private final BillingOutboxPublisher outboxPublisher;

    public ReceiptController(
            ReceiptQueryService receiptQueryService,
            ReceiptDeliveryService receiptDeliveryService,
            BillingOutboxPublisher outboxPublisher) {
        this.receiptQueryService = receiptQueryService;
        this.receiptDeliveryService = receiptDeliveryService;
        this.outboxPublisher = outboxPublisher;
    }

    @GetMapping("/availability")
    public List<ReceiptAvailabilityResponse> availability(
            @RequestHeader("X-User-Id") Long userId,
            @RequestParam List<String> bookingIds) {
        requireUserId(userId);
        return receiptQueryService.availability(userId, bookingIds);
    }

    @GetMapping("/{documentId}/download")
    public ResponseEntity<byte[]> download(
            @PathVariable String documentId,
            @RequestHeader("X-User-Id") Long userId) {
        requireUserId(userId);
        ReceiptFile receipt = receiptQueryService.downloadForUser(documentId, userId);
        return pdfResponse(receipt);
    }

    @PostMapping("/{documentId}/resend")
    public ResponseEntity<ResendReceiptResponse> resend(
            @PathVariable String documentId,
            @RequestHeader("X-User-Id") Long userId,
            @Valid @RequestBody(required = false) ResendReceiptRequest request) {
        requireUserId(userId);
        BillingOutbox outbox = receiptDeliveryService.requestResend(
                documentId,
                userId,
                request == null ? null : request.alternateEmail());
        outboxPublisher.tryPublish(outbox);
        return ResponseEntity.accepted().body(new ResendReceiptResponse(documentId, "QUEUED"));
    }

    private ResponseEntity<byte[]> pdfResponse(ReceiptFile receipt) {
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
                        .filename(receipt.filename(), StandardCharsets.UTF_8)
                        .build()
                        .toString())
                .body(receipt.content());
    }

    private void requireUserId(Long userId) {
        if (userId == null || userId < 1) {
            throw new IllegalArgumentException("Trusted user identity is required");
        }
    }
}
