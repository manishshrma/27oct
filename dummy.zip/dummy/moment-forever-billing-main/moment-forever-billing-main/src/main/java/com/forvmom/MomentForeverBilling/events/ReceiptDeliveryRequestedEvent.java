package com.forvmom.MomentForeverBilling.events;

import lombok.Data;

import java.time.Instant;

@Data
public class ReceiptDeliveryRequestedEvent {

    private String eventId;
    private String producer;
    private String correlationId;
    private Instant occurredAt;
    private String eventType;
    private String documentId;
    private String bookingId;
    private Long userId;
    private String recipientEmail;
    private String receiptNumber;
    private boolean resend;
}
