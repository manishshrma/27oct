package com.forvmom.MomentForeverBilling.dto;

import java.time.Instant;

public record AdminOutboxResponse(
        String aggregateId,
        String eventType,
        String status,
        int retryCount,
        Instant createdAt,
        Instant updatedAt) {
}
