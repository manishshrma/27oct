package com.forvmom.MomentForeverBilling.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
public class ReceiptCandidateDltConsumer {

    private static final Logger log = LoggerFactory.getLogger(ReceiptCandidateDltConsumer.class);

    @KafkaListener(
            topics = {
                    "${kafka.topics.receipt-generation-requested-dlt}",
                    "${kafka.topics.receipt-eligibility-captured-dlt}",
                    "${kafka.topics.experience-completed-dlt}"
            },
            groupId = "billing-receipt-dlt-observer-group",
            containerFactory = "billingDltKafkaListenerContainerFactory")
    public void onDeadLetter(ConsumerRecord<String, byte[]> record, Acknowledgment acknowledgment) {
        log.error("Billing receipt event is on the DLT: topic={}, partition={}, offset={}",
                record.topic(), record.partition(), record.offset());
        acknowledgment.acknowledge();
    }
}
