package com.forvmom.MomentForeverBilling.dto;

import java.time.Instant;

public record ReceiptAvailabilityResponse(
        String bookingId,
        boolean available,
        String documentId,
        String receiptNumber,
        Instant issuedAt,
        String state) {
}
