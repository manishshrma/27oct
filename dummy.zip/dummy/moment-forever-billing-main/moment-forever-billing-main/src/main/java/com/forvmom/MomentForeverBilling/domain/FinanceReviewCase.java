package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Document("finance_review_cases")
@CompoundIndexes({
        @CompoundIndex(name = "uq_finance_review_booking_event",
                def = "{'bookingId': 1, 'sourceEventId': 1}", unique = true)
})
public class FinanceReviewCase {

    @Id
    private String id;

    private String bookingId;

    private String sourceEventId;
    private String reasonCode;
    private BigDecimal expectedAmount;
    private BigDecimal paidAmount;
    private String expectedCurrency;
    private String paidCurrency;
    private String paymentTransactionId;
    private String status;
    private Instant createdAt;
}
