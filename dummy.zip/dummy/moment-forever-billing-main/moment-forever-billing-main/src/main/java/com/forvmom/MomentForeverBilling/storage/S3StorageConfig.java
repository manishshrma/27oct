package com.forvmom.MomentForeverBilling.storage;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.net.URI;

@Configuration
@ConditionalOnProperty(name = "billing.storage.provider", havingValue = "s3")
public class S3StorageConfig {

    @Bean
    public S3Client fiscalDocumentS3Client(BillingProperties properties) {
        var builder = S3Client.builder()
                .region(Region.of(properties.getStorage().getS3Region()));
        if (StringUtils.hasText(properties.getStorage().getS3Endpoint())) {
            builder.endpointOverride(URI.create(properties.getStorage().getS3Endpoint()));
        }
        return builder.build();
    }
}
