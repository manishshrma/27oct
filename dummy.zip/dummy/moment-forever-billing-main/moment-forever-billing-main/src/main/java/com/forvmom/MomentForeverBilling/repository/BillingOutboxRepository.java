package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Collection;
import java.util.List;

public interface BillingOutboxRepository extends MongoRepository<BillingOutbox, String> {

    List<BillingOutbox> findTop100ByStatusInOrderByUpdatedAtAsc(OutboxStatus status);

    List<BillingOutbox> findTop100ByStatusInOrderByCreatedAtAsc(OutboxStatus status);

    List<BillingOutbox> findByStatusInOrderByUpdatedAtAsc(Collection<OutboxStatus> statuses);
}
