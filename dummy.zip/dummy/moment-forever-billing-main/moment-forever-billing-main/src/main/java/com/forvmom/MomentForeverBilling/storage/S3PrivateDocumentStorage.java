package com.forvmom.MomentForeverBilling.storage;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.StorageMetadata;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.InputStream;
import java.util.UUID;

@Component
@ConditionalOnProperty(name = "billing.storage.provider", havingValue = "s3")
public class S3PrivateDocumentStorage implements PrivateDocumentStorage {

    private final S3Client s3Client;
    private final BillingProperties properties;

    public S3PrivateDocumentStorage(S3Client fiscalDocumentS3Client, BillingProperties properties) {
        this.s3Client = fiscalDocumentS3Client;
        this.properties = properties;
    }

    @Override
    public String provider() {
        return "s3";
    }

    @Override
    public StoredDocument store(byte[] content, String contentType) {
        String bucket = requiredBucket();
        String key = "fiscal-documents/" + UUID.randomUUID() + ".pdf";
        s3Client.putObject(PutObjectRequest.builder()
                        .bucket(bucket)
                        .key(key)
                        .contentType(contentType)
                        .metadata(java.util.Map.of("immutable", "true"))
                        .build(),
                RequestBody.fromBytes(content));
        return new StoredDocument(provider(), key, content.length, contentType);
    }

    @Override
    public InputStream open(StorageMetadata metadata) {
        ResponseInputStream<GetObjectResponse> stream = s3Client.getObject(
                GetObjectRequest.builder()
                        .bucket(requiredBucket())
                        .key(metadata.getStorageKey())
                        .build());
        return stream;
    }

    @Override
    public void delete(StorageMetadata metadata) {
        s3Client.deleteObject(builder -> builder
                .bucket(requiredBucket())
                .key(metadata.getStorageKey()));
    }

    private String requiredBucket() {
        String bucket = properties.getStorage().getS3Bucket();
        if (!StringUtils.hasText(bucket)) {
            throw new IllegalStateException("billing.storage.s3-bucket is required when S3 storage is selected");
        }
        return bucket;
    }
}
