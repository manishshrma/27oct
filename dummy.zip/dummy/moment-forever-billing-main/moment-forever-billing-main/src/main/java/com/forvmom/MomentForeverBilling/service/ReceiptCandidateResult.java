package com.forvmom.MomentForeverBilling.service;

public record ReceiptCandidateResult(String resolutionCode) {

    public static ReceiptCandidateResult resolved(String resolutionCode) {
        return new ReceiptCandidateResult(resolutionCode);
    }
}
