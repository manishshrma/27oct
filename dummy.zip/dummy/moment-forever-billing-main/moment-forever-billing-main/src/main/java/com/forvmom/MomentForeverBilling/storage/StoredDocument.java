package com.forvmom.MomentForeverBilling.storage;

public record StoredDocument(
        String provider,
        String storageKey,
        long sizeBytes,
        String contentType) {
}
