package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.ExperienceCompletionEvidence;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ExperienceCompletionEvidenceRepository
        extends MongoRepository<ExperienceCompletionEvidence, String> {

    Optional<ExperienceCompletionEvidence> findByEventId(String eventId);

    Optional<ExperienceCompletionEvidence> findByBookingId(String bookingId);
}
