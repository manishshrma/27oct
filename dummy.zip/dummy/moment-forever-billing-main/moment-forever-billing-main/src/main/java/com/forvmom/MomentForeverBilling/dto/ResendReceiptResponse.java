package com.forvmom.MomentForeverBilling.dto;

public record ResendReceiptResponse(String documentId, String status) {
}
