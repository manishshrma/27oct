package com.forvmom.MomentForeverBilling.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Instant;

@ConfigurationProperties(prefix = "billing")
public class BillingProperties {

    private String issuerName = "Moment Forever";
    private String issuerCountry = "IN";
    private String currency = "INR";
    private String receiptPrefix = "MF-R";
    private int financialYearStartMonth = 4;
    private Instant receiptFeatureLaunchAt = Instant.parse("2026-01-01T00:00:00Z");
    private int outboxMaxRetries = 5;
    private Storage storage = new Storage();
    private Resend resend = new Resend();
    private Admin admin = new Admin();

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getIssuerCountry() {
        return issuerCountry;
    }

    public void setIssuerCountry(String issuerCountry) {
        this.issuerCountry = issuerCountry;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getReceiptPrefix() {
        return receiptPrefix;
    }

    public void setReceiptPrefix(String receiptPrefix) {
        this.receiptPrefix = receiptPrefix;
    }

    public int getFinancialYearStartMonth() {
        return financialYearStartMonth;
    }

    public void setFinancialYearStartMonth(int financialYearStartMonth) {
        this.financialYearStartMonth = financialYearStartMonth;
    }

    public Instant getReceiptFeatureLaunchAt() {
        return receiptFeatureLaunchAt;
    }

    public void setReceiptFeatureLaunchAt(Instant receiptFeatureLaunchAt) {
        this.receiptFeatureLaunchAt = receiptFeatureLaunchAt;
    }

    public int getOutboxMaxRetries() {
        return outboxMaxRetries;
    }

    public void setOutboxMaxRetries(int outboxMaxRetries) {
        this.outboxMaxRetries = outboxMaxRetries;
    }

    public Storage getStorage() {
        return storage;
    }

    public void setStorage(Storage storage) {
        this.storage = storage;
    }

    public Resend getResend() {
        return resend;
    }

    public void setResend(Resend resend) {
        this.resend = resend;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public static class Storage {
        private String provider = "gridfs";
        private String gridfsBucket = "fiscal-documents";
        private String s3Bucket;
        private String s3Region = "ap-south-1";
        private String s3Endpoint;

        public String getProvider() {
            return provider;
        }

        public void setProvider(String provider) {
            this.provider = provider;
        }

        public String getGridfsBucket() {
            return gridfsBucket;
        }

        public void setGridfsBucket(String gridfsBucket) {
            this.gridfsBucket = gridfsBucket;
        }

        public String getS3Bucket() {
            return s3Bucket;
        }

        public void setS3Bucket(String s3Bucket) {
            this.s3Bucket = s3Bucket;
        }

        public String getS3Region() {
            return s3Region;
        }

        public void setS3Region(String s3Region) {
            this.s3Region = s3Region;
        }

        public String getS3Endpoint() {
            return s3Endpoint;
        }

        public void setS3Endpoint(String s3Endpoint) {
            this.s3Endpoint = s3Endpoint;
        }
    }

    public static class Resend {
        private int maxPerHour = 3;

        public int getMaxPerHour() {
            return maxPerHour;
        }

        public void setMaxPerHour(int maxPerHour) {
            this.maxPerHour = maxPerHour;
        }
    }

    public static class Admin {
        private boolean endpointsEnabled;
        private boolean swaggerVisible;

        public boolean isEndpointsEnabled() {
            return endpointsEnabled;
        }

        public void setEndpointsEnabled(boolean endpointsEnabled) {
            this.endpointsEnabled = endpointsEnabled;
        }

        public boolean isSwaggerVisible() {
            return swaggerVisible;
        }

        public void setSwaggerVisible(boolean swaggerVisible) {
            this.swaggerVisible = swaggerVisible;
        }
    }
}
