package com.forvmom.MomentForeverBilling.service;

public record ReceiptFile(String filename, byte[] content) {
}
