package com.forvmom.MomentForeverBilling.storage;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.StorageMetadata;
import com.mongodb.client.gridfs.model.GridFSFile;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

@Component
public class GridFsPrivateDocumentStorage implements PrivateDocumentStorage {

    private final GridFsTemplate gridFsTemplate;
    private final BillingProperties properties;

    public GridFsPrivateDocumentStorage(
            MongoDatabaseFactory databaseFactory,
            MongoConverter mongoConverter,
            BillingProperties properties) {
        this.gridFsTemplate = new GridFsTemplate(
                databaseFactory,
                mongoConverter,
                properties.getStorage().getGridfsBucket());
        this.properties = properties;
    }

    @Override
    public String provider() {
        return "gridfs";
    }

    @Override
    public StoredDocument store(byte[] content, String contentType) {
        ObjectId objectId = gridFsTemplate.store(
                new ByteArrayInputStream(content),
                "receipt-" + UUID.randomUUID() + ".pdf",
                contentType,
                new Document("bucket", properties.getStorage().getGridfsBucket())
                        .append("immutable", true));
        return new StoredDocument(provider(), objectId.toHexString(), content.length, contentType);
    }

    @Override
    public InputStream open(StorageMetadata metadata) {
        GridFSFile file = gridFsTemplate.findOne(
                Query.query(Criteria.where("_id").is(new ObjectId(metadata.getStorageKey()))));
        if (file == null) {
            throw new IllegalStateException("Private fiscal document content is unavailable");
        }
        GridFsResource resource = gridFsTemplate.getResource(file);
        try {
            return resource.getInputStream();
        } catch (IOException exception) {
            throw new IllegalStateException("Private fiscal document content cannot be opened", exception);
        }
    }

    @Override
    public void delete(StorageMetadata metadata) {
        gridFsTemplate.delete(Query.query(Criteria.where("_id").is(new ObjectId(metadata.getStorageKey()))));
    }
}
