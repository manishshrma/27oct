package com.forvmom.MomentForeverBilling.domain;

public enum ReceiptCandidateStatus {
    PENDING_COMPLETION,
    PREPARING,
    ISSUED,
    REVIEW_REQUIRED,
    NOT_ELIGIBLE
}
