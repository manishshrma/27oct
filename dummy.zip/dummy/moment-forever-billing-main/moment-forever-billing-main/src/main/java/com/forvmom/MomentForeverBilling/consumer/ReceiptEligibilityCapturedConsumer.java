package com.forvmom.MomentForeverBilling.consumer;

import com.forvmom.MomentForeverBilling.events.ReceiptEligibilityCapturedEvent;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateResult;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class ReceiptEligibilityCapturedConsumer {

    private static final Logger log = LoggerFactory.getLogger(ReceiptEligibilityCapturedConsumer.class);

    private final ReceiptCandidateService receiptCandidateService;

    public ReceiptEligibilityCapturedConsumer(ReceiptCandidateService receiptCandidateService) {
        this.receiptCandidateService = receiptCandidateService;
    }

    @KafkaListener(
            topics = "${kafka.topics.receipt-eligibility-captured}",
            groupId = "billing-receipt-candidate-group",
            containerFactory = "billingKafkaListenerContainerFactory")
    public void onReceiptEligibilityCaptured(
            @Payload ReceiptEligibilityCapturedEvent event,
            Acknowledgment acknowledgment) {
        ReceiptCandidateResult result = receiptCandidateService.capture(event);
        acknowledgment.acknowledge();
        log.info("Receipt eligibility captured: bookingId={}, resolution={}",
                event.getBookingId(), result.resolutionCode());
    }
}
