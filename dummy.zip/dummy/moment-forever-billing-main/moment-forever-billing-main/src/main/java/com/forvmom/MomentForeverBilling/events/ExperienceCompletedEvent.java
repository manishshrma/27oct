package com.forvmom.MomentForeverBilling.events;

import lombok.Data;

import java.time.Instant;

@Data
public class ExperienceCompletedEvent {

    private String eventId;
    private String producer;
    private String correlationId;
    private String causationId;
    private Integer schemaVersion;
    private Instant occurredAt;
    private String eventType;
    private String bookingId;
    private Long userId;
    private Long experienceId;
    private Instant completedAt;
}
