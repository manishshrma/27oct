package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.ReceiptResendRateLimit;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;

@Service
public class ReceiptResendRateLimiter {

    private final MongoTemplate mongoTemplate;
    private final BillingProperties properties;

    public ReceiptResendRateLimiter(MongoTemplate mongoTemplate, BillingProperties properties) {
        this.mongoTemplate = mongoTemplate;
        this.properties = properties;
    }

    public boolean tryAcquire(String documentId, Long userId) {
        int maximum = properties.getResend().getMaxPerHour();
        if (maximum < 1) {
            return false;
        }
        String key = documentId + ":" + userId;
        Instant now = Instant.now();
        Query activeWindow = new Query(new Criteria().andOperator(
                Criteria.where("_id").is(key),
                Criteria.where("windowExpiresAt").gt(now),
                Criteria.where("count").lt(maximum)));
        ReceiptResendRateLimit acquired = mongoTemplate.findAndModify(
                activeWindow,
                new Update().inc("count", 1),
                FindAndModifyOptions.options().returnNew(true),
                ReceiptResendRateLimit.class);
        if (acquired != null) {
            return true;
        }

        Query expiredOrMissingWindow = new Query(new Criteria().andOperator(
                Criteria.where("_id").is(key),
                new Criteria().orOperator(
                        Criteria.where("windowExpiresAt").exists(false),
                        Criteria.where("windowExpiresAt").lte(now))));
        Update resetWindow = new Update()
                .set("count", 1)
                .set("windowExpiresAt", now.plus(Duration.ofHours(1)));
        try {
            return mongoTemplate.findAndModify(
                    expiredOrMissingWindow,
                    resetWindow,
                    FindAndModifyOptions.options().upsert(true).returnNew(true),
                    ReceiptResendRateLimit.class) != null;
        } catch (DuplicateKeyException ignored) {
            return false;
        }
    }
}
